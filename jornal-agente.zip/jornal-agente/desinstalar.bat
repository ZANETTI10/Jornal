@echo off
REM Jornal - detener y quitar el agente
schtasks /End /TN "Jornal agente" 2>nul
schtasks /Delete /TN "Jornal agente" /F
taskkill /F /FI "WINDOWTITLE eq Jornal*" >nul 2>nul
for /f "tokens=2 delims=," %%p in ('wmic process where "name='pythonw.exe' and commandline like '%%jornal_agente%%'" get processid /format:csv ^| findstr /r "[0-9]"') do taskkill /F /PID %%p >nul 2>nul
echo  Agente detenido y quitado del inicio automatico.
pause
