@echo off
REM Jornal - instalador del agente del reloj biometrico
cd /d "%~dp0"
echo.
echo  ===== Jornal: agente del reloj biometrico =====
echo.
python -c "import sys; assert sys.version_info >= (3, 8)" 2>nul
if errorlevel 1 (
  echo  No encuentro Python 3 en este PC.
  echo  1. Se abre la pagina de descarga. Instala Python y MARCA la casilla "Add python.exe to PATH".
  echo  2. Cierra esta ventana y vuelve a abrir instalar.bat
  start https://www.python.org/downloads/windows/
  pause
  exit /b 1
)
echo  Instalando el componente para hablar con el reloj (pyzk)...
python -m pip install --upgrade --disable-pip-version-check pyzk
if errorlevel 1 (
  echo  No se pudo instalar pyzk. Revisa que el PC tenga internet y vuelve a intentar.
  pause
  exit /b 1
)
echo.
python jornal_agente.py --configurar
echo  Probando el reloj y Jornal...
python jornal_agente.py --probar
if errorlevel 1 (
  echo  La prueba fallo. Revisa la IP del reloj y la llave, y vuelve a ejecutar instalar.bat
  pause
  exit /b 1
)
for /f "delims=" %%i in ('python -c "import sys, os; print(os.path.join(os.path.dirname(sys.executable), 'pythonw.exe'))"') do set "PYW=%%i"
schtasks /Create /TN "Jornal agente" /TR "\"%PYW%\" \"%~dp0jornal_agente.py\"" /SC ONLOGON /RL LIMITED /F
schtasks /Run /TN "Jornal agente"
echo.
echo  Listo. El agente queda funcionando y arranca solo cada vez que se inicia sesion en este PC.
echo  El registro de lo que hace queda en jornal_agente.log (en esta misma carpeta).
echo.
pause
