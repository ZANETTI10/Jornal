# -*- coding: utf-8 -*-
"""
Jornal · agente del reloj biométrico
====================================
Corre en un PC de la empresa que esté en la misma red que el reloj ZKTeco.
  1. Al arrancar descarga del reloj las marcaciones pendientes y las sube a Jornal.
  2. Luego se queda escuchando el reloj: cada marcación nueva llega a Jornal
     en segundos (tiempo real).
  3. Cada 30 minutos repasa todo el reloj por si algo se perdió y le cuenta a Jornal
     qué usuarios tiene el reloj.
  4. Ejecuta en el reloj las órdenes que se dan desde Jornal (poner nombre, eliminar usuario).
Si se cae internet o el reloj, guarda lo pendiente y lo reintenta solo.

Uso:
  python jornal_agente.py --configurar   pide los datos y los guarda en config.ini
  python jornal_agente.py --probar       prueba el reloj y Jornal, sin enviar nada
  python jornal_agente.py                funciona sin parar (lo que hace la tarea programada)
"""
import configparser
import datetime as dt
import json
import logging
import logging.handlers
import os
import sys
import time
import unicodedata
import urllib.error
import urllib.request

VERSION = "1.1"
CARPETA = os.path.dirname(os.path.abspath(__file__))
RUTA_CONFIG = os.path.join(CARPETA, "config.ini")
RUTA_ESTADO = os.path.join(CARPETA, "estado.json")
RUTA_PENDIENTES = os.path.join(CARPETA, "pendientes.json")
URL_JORNAL = "https://klsomxbzefbqugotglmh.supabase.co/functions/v1/recibir-marcaciones"
LOTE = 1000
REPASO_MIN = 30

log = logging.getLogger("jornal")


def preparar_log():
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s  %(levelname)s  %(message)s", "%Y-%m-%d %H:%M:%S")
    archivo = logging.handlers.RotatingFileHandler(os.path.join(CARPETA, "jornal_agente.log"),
                                                   maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    archivo.setFormatter(fmt)
    log.addHandler(archivo)
    if sys.stdout and sys.stdout.isatty():
        consola = logging.StreamHandler(sys.stdout)
        consola.setFormatter(fmt)
        log.addHandler(consola)


# ---------------------------------------------------------------- configuración
def leer_config():
    if not os.path.exists(RUTA_CONFIG):
        sys.exit("Falta config.ini. Ejecuta primero:  python jornal_agente.py --configurar")
    c = configparser.ConfigParser()
    c.read(RUTA_CONFIG, encoding="utf-8")
    return {
        "ip": c.get("reloj", "ip"),
        "puerto": c.getint("reloj", "puerto", fallback=4370),
        "clave": c.getint("reloj", "clave", fallback=0),
        "udp": c.getboolean("reloj", "udp", fallback=False),
        "llave": c.get("jornal", "llave").strip(),
        "url": c.get("jornal", "url", fallback=URL_JORNAL).strip(),
        "desde": c.get("jornal", "desde", fallback=dt.date.today().replace(day=1).isoformat()),
    }


def configurar():
    print("\nConfiguración del agente de Jornal\n")
    previo = configparser.ConfigParser()
    if os.path.exists(RUTA_CONFIG):
        previo.read(RUTA_CONFIG, encoding="utf-8")

    def preguntar(texto, seccion, clave, defecto):
        actual = previo.get(seccion, clave, fallback=defecto)
        r = input(f"{texto} [{actual}]: ").strip()
        return r or actual

    ip = preguntar("IP del reloj", "reloj", "ip", "192.168.10.252")
    puerto = preguntar("Puerto del reloj", "reloj", "puerto", "4370")
    clave = preguntar("Contraseña de comunicación del reloj (0 si no tiene)", "reloj", "clave", "0")
    llave = ""
    while not (llave.startswith("jrn_") and len(llave) == 52):
        llave = input("Llave del reloj (la copias de Jornal → Ajustes → Empresas → Relojes): ").strip() \
            or previo.get("jornal", "llave", fallback="")
        if not (llave.startswith("jrn_") and len(llave) == 52):
            print("  Esa llave no se ve bien: empieza por jrn_ y tiene 52 caracteres.")
    desde = preguntar("Subir marcaciones desde (AAAA-MM-DD)", "jornal", "desde",
                      dt.date.today().replace(day=1).isoformat())
    c = configparser.ConfigParser()
    c["reloj"] = {"ip": ip, "puerto": puerto, "clave": clave, "udp": "no"}
    c["jornal"] = {"llave": llave, "url": URL_JORNAL, "desde": desde}
    with open(RUTA_CONFIG, "w", encoding="utf-8") as f:
        c.write(f)
    print("\nGuardado en config.ini\n")


# ---------------------------------------------------------------- archivos de estado
def leer_json(ruta, defecto):
    try:
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defecto


def guardar_json(ruta, dato):
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(dato, f, ensure_ascii=False)
    os.replace(tmp, ruta)


# ---------------------------------------------------------------- Jornal
def llamar_jornal(cfg, cuerpo, intentos=3):
    datos = json.dumps(cuerpo).encode("utf-8")
    for n in range(intentos):
        req = urllib.request.Request(cfg["url"], data=datos, method="POST", headers={
            "Content-Type": "application/json", "x-llave-dispositivo": cfg["llave"],
            "User-Agent": f"JornalAgente/{VERSION}"})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            texto = e.read().decode("utf-8", "ignore")
            if e.code in (400, 401, 403):
                raise RuntimeError(f"Jornal rechazó el envío ({e.code}): {texto}")
            log.warning("Jornal respondió %s, reintento: %s", e.code, texto[:200])
        except (urllib.error.URLError, OSError) as e:
            log.warning("Sin conexión con Jornal (%s), reintento", e)
        time.sleep(5 * (n + 1))
    raise ConnectionError("Jornal no responde")


# ---------------------------------------------------------------- reloj
ENTRADAS, SALIDAS = {0, 3, 4}, {1, 2, 5}   # check-in, break-in, OT-in / check-out, break-out, OT-out


def a_marcacion(a):
    # Se guarda al minuto, igual que el reporte del ZKTime, para no duplicar lo ya importado por archivo
    t = a.timestamp.replace(second=0, microsecond=0)
    tipo = "entrada" if a.punch in ENTRADAS else "salida" if a.punch in SALIDAS else None
    return {"codigo": str(a.user_id).strip(), "fecha_hora": t.strftime("%Y-%m-%d %H:%M:%S"), "tipo": tipo}


def conectar(cfg):
    from zk import ZK  # pip install pyzk
    zk = ZK(cfg["ip"], port=cfg["puerto"], timeout=20, password=cfg["clave"],
            force_udp=cfg["udp"], ommit_ping=True)
    return zk.connect()


def info_reloj(conn):
    info = {"agente": VERSION}
    for clave, fn in (("serial", conn.get_serialnumber), ("modelo", conn.get_device_name),
                      ("firmware", conn.get_firmware_version)):
        try:
            info[clave] = fn()
        except Exception:
            pass
    try:
        conn.read_sizes()
        info.update(usuarios=conn.users, huellas=conn.fingers, eventos=conn.records)
    except Exception:
        pass
    return info


# ---------------------------------------------------------------- envío
def enviar(cfg, marcaciones, nombres, info=None):
    """Envía en lotes; lo que no se pueda enviar queda en pendientes.json."""
    pendientes = leer_json(RUTA_PENDIENTES, []) + marcaciones
    if not pendientes:
        return 0
    nuevas = 0
    while pendientes:
        lote = pendientes[:LOTE]
        codigos = {m["codigo"] for m in lote}
        cuerpo = {"accion": "enviar", "marcaciones": lote,
                  "usuarios": [{"codigo": c, "nombre": nombres.get(c, "")} for c in codigos]}
        if info:
            cuerpo["info"] = info
        try:
            r = llamar_jornal(cfg, cuerpo)
        except ConnectionError:
            guardar_json(RUTA_PENDIENTES, pendientes)
            log.warning("Quedan %d marcaciones pendientes; se reintenta luego", len(pendientes))
            return nuevas
        nuevas += r.get("nuevas", 0)
        if r.get("empleados_creados"):
            log.info("Jornal creó %d empleados nuevos con ficha provisional", r["empleados_creados"])
        pendientes = pendientes[LOTE:]
        guardar_json(RUTA_PENDIENTES, pendientes)
        mayor = max(m["fecha_hora"] for m in lote)
        estado = leer_json(RUTA_ESTADO, {})
        if mayor > estado.get("ultima", ""):
            estado["ultima"] = mayor
            guardar_json(RUTA_ESTADO, estado)
    return nuevas


def cursor(cfg):
    """Desde cuándo subir: lo último enviado (con 2 días de margen) o la fecha 'desde' del config."""
    ultima = leer_json(RUTA_ESTADO, {}).get("ultima")
    if not ultima:
        try:
            ultima = llamar_jornal(cfg, {"accion": "estado"}).get("ultima_marcacion")
        except Exception:
            ultima = None
    if ultima:
        base = dt.datetime.strptime(ultima[:19].replace("T", " "), "%Y-%m-%d %H:%M:%S") - dt.timedelta(days=2)
        return max(base, dt.datetime.fromisoformat(cfg["desde"]))
    return dt.datetime.fromisoformat(cfg["desde"])


def nombre_para_reloj(nombre):
    """El reloj guarda el nombre en 24 letras sin tildes."""
    t = unicodedata.normalize("NFKD", str(nombre or "")).encode("ascii", "ignore").decode("ascii")
    return " ".join(t.split())[:24].strip()


def enviar_usuarios(cfg, usuarios, registros):
    """Le cuenta a Jornal qué usuarios tiene el reloj y cuándo marcó cada uno por última vez."""
    ultima, cuenta = {}, {}
    for a in registros:
        c = str(a.user_id).strip()
        cuenta[c] = cuenta.get(c, 0) + 1
        if c not in ultima or a.timestamp > ultima[c]:
            ultima[c] = a.timestamp
    lista = [{"codigo": str(u.user_id).strip(), "uid": u.uid, "nombre": u.name, "privilegio": u.privilege,
              "ultima": ultima[str(u.user_id).strip()].strftime("%Y-%m-%d %H:%M:%S") if str(u.user_id).strip() in ultima else None,
              "marcaciones": cuenta.get(str(u.user_id).strip(), 0)} for u in usuarios]
    try:
        llamar_jornal(cfg, {"accion": "usuarios", "usuarios": lista})
    except Exception as e:
        log.warning("No se pudo enviar la lista de usuarios del reloj: %s", e)


def pedir_comandos(cfg):
    try:
        return llamar_jornal(cfg, {"accion": "comandos"}, intentos=1).get("comandos", [])
    except Exception:
        return []


def ejecutar_comandos(cfg, conn, usuarios, comandos):
    """Pone nombres o elimina usuarios en el reloj según las órdenes de Jornal."""
    if not comandos:
        return False
    por_codigo = {str(u.user_id).strip(): u for u in usuarios}
    resultados = []
    try:
        conn.disable_device()
        for c in comandos:
            u = por_codigo.get(str(c["codigo"]))
            try:
                if not u:
                    resultados.append({"id": c["id"], "ok": c["tipo"] == "eliminar", "mensaje": "El código no está en el reloj"})
                elif c["tipo"] == "nombre":
                    nuevo = nombre_para_reloj(c.get("nombre"))
                    if not nuevo:
                        raise ValueError("nombre vacío")
                    conn.set_user(uid=u.uid, name=nuevo, privilege=u.privilege, password=u.password,
                                  group_id=u.group_id, user_id=u.user_id, card=u.card)
                    resultados.append({"id": c["id"], "ok": True, "mensaje": f"Nombre puesto: {nuevo}"})
                    log.info("Reloj: código %s ahora se llama %s", c["codigo"], nuevo)
                elif c["tipo"] == "eliminar":
                    if u.privilege == 14:
                        resultados.append({"id": c["id"], "ok": False, "mensaje": "Es administrador del reloj; no se elimina"})
                        continue
                    conn.delete_user(uid=u.uid)
                    resultados.append({"id": c["id"], "ok": True, "mensaje": "Eliminado del reloj"})
                    log.info("Reloj: código %s eliminado", c["codigo"])
            except Exception as e:
                resultados.append({"id": c["id"], "ok": False, "mensaje": str(e)[:200]})
        try:
            conn.refresh_data()
        except Exception:
            pass
    finally:
        try:
            conn.enable_device()
        except Exception:
            pass
    try:
        llamar_jornal(cfg, {"accion": "resultado", "resultados": resultados})
    except Exception as e:
        log.warning("No se pudo informar el resultado de las órdenes: %s", e)
    return True


def repaso_completo(cfg, conn):
    """Lee todo el reloj, sube lo que falte, informa los usuarios y ejecuta las órdenes pendientes."""
    usuarios = conn.get_users()
    nombres = {str(u.user_id): u.name for u in usuarios}
    desde = cursor(cfg)
    registros = conn.get_attendance()
    marc = [a_marcacion(a) for a in registros if a.timestamp >= desde]
    info = info_reloj(conn)
    nuevas = enviar(cfg, marc, nombres, info)
    log.info("Repaso: %d eventos en el reloj, %d desde %s, %d nuevas en Jornal",
             len(registros), len(marc), desde.strftime("%Y-%m-%d"), nuevas)
    if ejecutar_comandos(cfg, conn, usuarios, pedir_comandos(cfg)):
        usuarios = conn.get_users()
        nombres = {str(u.user_id): u.name for u in usuarios}
    enviar_usuarios(cfg, usuarios, registros)
    return nombres


def escuchar(cfg, conn, nombres):
    """Tiempo real: cada marcación se envía apenas ocurre. Sale cada REPASO_MIN para repasar,
    o antes si Jornal dejó órdenes para el reloj (se revisa cada minuto)."""
    limite = time.time() + REPASO_MIN * 60
    revisar = time.time() + 60
    for a in conn.live_capture(new_timeout=10):
        if a is not None:
            m = a_marcacion(a)
            n = enviar(cfg, [m], nombres)
            log.info("Marcación en vivo: código %s %s %s (%s)", m["codigo"], m["fecha_hora"],
                     m["tipo"] or "", "nueva" if n else "ya estaba")
        elif leer_json(RUTA_PENDIENTES, []):
            enviar(cfg, [], nombres)
        if time.time() > revisar:
            revisar = time.time() + 60
            if pedir_comandos(cfg):
                log.info("Jornal dejó órdenes para el reloj; se ejecutan ahora")
                conn.end_live_capture = True
        if time.time() > limite:
            conn.end_live_capture = True


def funcionar(cfg):
    log.info("Agente Jornal %s iniciado · reloj %s:%s", VERSION, cfg["ip"], cfg["puerto"])
    espera = 30
    while True:
        conn = None
        try:
            conn = conectar(cfg)
            nombres = repaso_completo(cfg, conn)
            espera = 30
            escuchar(cfg, conn, nombres)
        except RuntimeError as e:          # Jornal rechazó: llave mala o reloj inactivo
            log.error("%s. Revisa la llave en config.ini; nuevo intento en 10 minutos.", e)
            time.sleep(600)
        except Exception as e:
            log.warning("Sin conexión con el reloj o con Jornal (%s). Nuevo intento en %d s.", e, espera)
            time.sleep(espera)
            espera = min(espera * 2, 600)
        finally:
            if conn:
                try:
                    conn.disconnect()
                except Exception:
                    pass


def probar(cfg):
    print(f"\n1) Reloj {cfg['ip']}:{cfg['puerto']} …")
    conn = conectar(cfg)
    try:
        info = info_reloj(conn)
        print(f"   OK · {info.get('modelo', '?')} · serie {info.get('serial', '?')} · "
              f"{info.get('usuarios', '?')} usuarios · {info.get('huellas', '?')} huellas · {info.get('eventos', '?')} eventos")
        ultimas = sorted(conn.get_attendance(), key=lambda a: a.timestamp)[-3:]
        for a in ultimas:
            print("   última:", a_marcacion(a))
    finally:
        conn.disconnect()
    print("\n2) Jornal …")
    r = llamar_jornal(cfg, {"accion": "estado"})
    print(f"   OK · reloj registrado como «{r.get('reloj')}» · última marcación recibida: {r.get('ultima_marcacion') or 'ninguna'}")
    print("\nTodo listo. Ya puedes instalar la tarea automática.\n")


if __name__ == "__main__":
    if "--configurar" in sys.argv:
        configurar()
        sys.exit(0)
    preparar_log()
    cfg = leer_config()
    if "--probar" in sys.argv:
        try:
            probar(cfg)
        except Exception as e:
            print(f"\nNo funcionó: {e}\n")
            sys.exit(1)
    else:
        funcionar(cfg)
